Create a project with the Cordova or Ionic2 and copy over the contents of the desired demo subfolder
