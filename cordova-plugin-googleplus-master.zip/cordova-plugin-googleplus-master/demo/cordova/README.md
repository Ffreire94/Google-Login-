Create a project with the Cordova copy over index.html
